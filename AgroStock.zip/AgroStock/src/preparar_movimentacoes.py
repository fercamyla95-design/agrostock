from pathlib import Path
import re
import pandas as pd

def extrair_quantidade(valor):
    if pd.isna(valor):
        return None
    match = re.search(r"[-+]?\d+(?:[.,]\d+)?", str(valor))
    return float(match.group(0).replace(",", ".")) if match else None

def preparar_movimentacoes(arquivo):
    df = pd.read_excel(arquivo)
    # Adapte os nomes das colunas conforme a versão do formulário.
    timestamp = df.columns[0]
    movimentacao = df.columns[1]

    meta = [
        c for c in df.columns
        if any(chave in str(c) for chave in [
            "Carimbo de data/hora",
            "Entrada ou Saída",
            "Outras Receitas",
            "Destino do Produto",
            "Observação",
            "Responsável"
        ])
    ]
    produtos = [c for c in df.columns if c not in meta]

    registros = []
    for _, row in df.iterrows():
        for coluna in produtos:
            quantidade = extrair_quantidade(row[coluna])
            if quantidade is None:
                continue

            match = re.search(r"\[(.*?)\]", str(coluna))
            produto = match.group(1).strip() if match else str(coluna).strip()

            registros.append({
                "data_hora": row[timestamp],
                "movimentacao": row[movimentacao],
                "produto": produto,
                "quantidade_litros": quantidade,
            })

    return pd.DataFrame(registros)

if __name__ == "__main__":
    arquivo = Path("data/respostas.xlsx")
    saida = Path("data/movimentacoes_normalizadas.csv")

    df = preparar_movimentacoes(arquivo)
    saida.parent.mkdir(exist_ok=True)
    df.to_csv(saida, index=False, encoding="utf-8-sig")
    print(f"{len(df)} movimentações normalizadas.")
