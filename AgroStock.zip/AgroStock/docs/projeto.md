# AgroStock — Identidade do projeto

**Nome:** AgroStock

**Subtítulo:** Controle e rastreabilidade de estoque de insumos agrícolas

**Contexto:** Fazenda Triângulo

**Tipo:** Projeto real de automação e organização de dados no agronegócio

## Escopo desta versão

Esta versão documenta a solução que foi efetivamente utilizada em campo:

- QR Code para acesso rápido ao formulário;
- Google Forms para registro das movimentações;
- registro automático de data e hora;
- identificação do responsável;
- seleção de produto e quantidade;
- entrada ou saída;
- destino/talhão;
- armazenamento das respostas em planilha;
- transferência manual para a planilha operacional;
- controle de estoque.

## O que ainda não faz parte da versão original

Automação via Python/Pandas, banco de dados, dashboard e integrações serão tratados posteriormente como evolução do AgroStock.

## Privacidade

Os nomes dos responsáveis não devem aparecer no repositório público. Nos dados de demonstração, eles são substituídos por identificadores como `Responsável 01`, `Responsável 02` etc.

Os nomes dos talhões/localidades utilizados pela fazenda podem ser mantidos quando não revelarem endereço ou outra informação sensível.

## Formulário e visualização administrativa

O formulário original está desativado e pode ser consultado como referência da interface utilizada no projeto. O Google Forms também oferecia aos administradores uma prévia gráfica das respostas, útil para visualizar a distribuição dos registros sem abrir cada resposta individualmente.
