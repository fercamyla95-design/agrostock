# Fluxo do AgroStock

## 1. Coleta

O QR Code funciona como ponto de entrada para o formulário. O objetivo é reduzir o atrito para o usuário que está realizando a retirada/devolução.

## 2. Registro

O formulário registra automaticamente a data/hora e coleta as informações necessárias para identificar a movimentação.

## 3. Armazenamento

As respostas são armazenadas em uma planilha de respostas.

## 4. Organização

Na primeira versão, parte dos dados era transferida manualmente para a planilha operacional do AgroStock de controle de estoque.

Esse ponto é uma oportunidade importante de evolução: automatizar a transformação das respostas em uma tabela de movimentações normalizada.

## 5. Controle

A planilha operacional do AgroStock consolida entradas e saídas e calcula o estoque atual por produto.

## 6. Melhoria contínua

Durante os aproximadamente cinco meses de uso, o processo passou por ajustes conforme os usuários encontravam dificuldades ou novas necessidades.
